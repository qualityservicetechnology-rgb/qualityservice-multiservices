function toggleMenu() {
    document.getElementById('navMenu').classList.toggle('open');
}